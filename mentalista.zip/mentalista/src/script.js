//numero randomico de 0 a 10 com parseInt para ser numero inteiro
var numeroSecreto = parseInt(Math.random() * 11);

function Chutar() {
  var elementoResultado = document.getElementById("resultado");
  var chute = parseInt(document.getElementById("valor").value);
  console.log(chute);

  //verificar se o chute está certo ou errado
  /*se chute for igual ao numer5o secreto acerto*/
  //|| quer dizer OU

  if (chute == numeroSecreto) {
    elementoResultado.innerHTML = "Você acertou Parabéns!!!";
  } else if (chute > 10 || chute < 0) {
    elementoResultado.innerHTML = "Você deve digitar um número de 0 a 10";
  } else {
    elementoResultado.innerHTML =
      "Você errou, o número secreto era: " + numeroSecreto;
  }
}
